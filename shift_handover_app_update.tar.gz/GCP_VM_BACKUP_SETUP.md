# 🚀 GCP VM Backup System Setup Guide

Your Shift Handover Application is running on GCP VM with MySQL database. Here's the complete backup system setup.

## 📋 Current VM Configuration

- **VM IP**: 35.200.202.18
- **Username**: shifthandoversajid
- **SSH Key**: ~/.ssh/my-gcp-key
- **App Directory**: /home/shifthandoversajid/shift_handover_app_26102025
- **Database**: MySQL 8.0 (Docker container: shift_handover_app_db_1)
- **Web App**: Flask (Docker container: shift_handover_app_web_1)

## 🗄️ Database Configuration

From docker-compose.yml:
- **Database Name**: shift_handover
- **User**: user
- **Password**: password
- **Root Password**: rootpassword
- **Port**: 3306

## 📁 Backup System Structure

```
/home/shifthandoversajid/
├── scripts/                    # Backup scripts
│   ├── backup_application.sh   # Full application backup
│   ├── mysql_backup.sh        # MySQL backup script
│   └── backup_monitor.sh      # Monitoring script
├── backups/                   # Backup storage
│   ├── daily/                 # Daily backups
│   ├── weekly/                # Weekly backups
│   ├── monthly/               # Monthly backups
│   └── database/              # Database backups
└── logs/                      # Backup logs
    ├── backup.log
    ├── db_backup.log
    └── cleanup.log
```

## 🛠️ Setup Instructions

### Step 1: Connect to VM
```bash
ssh -i ~/.ssh/my-gcp-key shifthandoversajid@35.200.202.18
```

### Step 2: Create Backup Directories
```bash
mkdir -p /home/shifthandoversajid/{scripts,backups/{daily,weekly,monthly,database},logs}
chmod 755 /home/shifthandoversajid/{scripts,backups,logs}
```

### Step 3: Create MySQL Backup Script
```bash
cat > /home/shifthandoversajid/scripts/mysql_backup.sh << 'EOF'
#!/bin/bash

# MySQL Database Backup Script for Shift Handover App
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_DIR="/home/shifthandoversajid/backups/database"
CONTAINER_NAME="shift_handover_app_db_1"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

log() { echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1"; }
success() { echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')] SUCCESS:${NC} $1"; }
error() { echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')] ERROR:${NC} $1" >&2; }

# Create backup
backup_mysql() {
    local backup_name="${1:-backup_${TIMESTAMP}}"
    local backup_file="${BACKUP_DIR}/${backup_name}.sql"
    
    log "Creating MySQL backup: $backup_name"
    
    # Check if container is running
    if ! docker ps | grep -q "$CONTAINER_NAME"; then
        error "MySQL container not running: $CONTAINER_NAME"
        return 1
    fi
    
    # Create backup
    docker exec "$CONTAINER_NAME" mysqldump -u user -ppassword \
        --single-transaction --routines --triggers \
        --databases shift_handover > "$backup_file" 2>/dev/null
    
    if [ $? -eq 0 ]; then
        # Compress backup
        gzip "$backup_file"
        backup_file="${backup_file}.gz"
        
        # Create metadata
        cat > "${backup_file}.info" << INFO
Backup: $backup_name
Date: $(date)
Size: $(ls -lh "$backup_file" | awk '{print $5}')
Container: $CONTAINER_NAME
Database: shift_handover
INFO
        
        success "Backup created: $backup_file"
        success "Size: $(ls -lh "$backup_file" | awk '{print $5}')"
    else
        error "Backup failed"
        return 1
    fi
}

# List backups
list_backups() {
    log "Available MySQL backups:"
    echo
    
    if [ ! -d "$BACKUP_DIR" ] || [ -z "$(ls -A "$BACKUP_DIR" 2>/dev/null)" ]; then
        echo "No backups found"
        return 0
    fi
    
    echo "Date                Size    File"
    echo "================== ======= =========================="
    
    for backup in "$BACKUP_DIR"/*.sql.gz; do
        if [ -f "$backup" ]; then
            local date_created=$(stat -c %y "$backup" | cut -d' ' -f1,2 | cut -d'.' -f1)
            local size=$(ls -lh "$backup" | awk '{print $5}')
            local filename=$(basename "$backup")
            
            printf "%-18s %-7s %s\n" "$date_created" "$size" "$filename"
        fi
    done
    echo
}

# Cleanup old backups
cleanup_backups() {
    local days="${1:-30}"
    log "Cleaning up backups older than $days days..."
    
    local count=$(find "$BACKUP_DIR" -name "*.sql.gz" -mtime +$days -delete -print | wc -l)
    find "$BACKUP_DIR" -name "*.info" -mtime +$days -delete
    
    success "Cleaned up $count old backup(s)"
}

# Test database connection
test_connection() {
    log "Testing MySQL connection..."
    
    if ! docker ps | grep -q "$CONTAINER_NAME"; then
        error "MySQL container not running"
        return 1
    fi
    
    if docker exec "$CONTAINER_NAME" mysql -u user -ppassword -e "SELECT 1;" &>/dev/null; then
        success "Database connection successful"
        return 0
    else
        error "Database connection failed"
        return 1
    fi
}

# Restore database
restore_backup() {
    local backup_file="$1"
    
    if [ ! -f "$backup_file" ]; then
        error "Backup file not found: $backup_file"
        return 1
    fi
    
    echo "WARNING: This will replace the current database!"
    echo -n "Type 'yes' to continue: "
    read confirmation
    
    if [ "$confirmation" = "yes" ]; then
        log "Restoring from: $backup_file"
        
        if [[ "$backup_file" == *.gz ]]; then
            gunzip -c "$backup_file" | docker exec -i "$CONTAINER_NAME" mysql -u user -ppassword
        else
            docker exec -i "$CONTAINER_NAME" mysql -u user -ppassword < "$backup_file"
        fi
        
        success "Database restored successfully"
    else
        log "Restore cancelled"
    fi
}

# Main function
case "${1:-}" in
    backup)
        backup_mysql "$2"
        ;;
    list)
        list_backups
        ;;
    cleanup)
        cleanup_backups "$2"
        ;;
    test)
        test_connection
        ;;
    restore)
        restore_backup "$2"
        ;;
    *)
        echo "Usage: $0 {backup|list|cleanup|test|restore}"
        echo ""
        echo "Commands:"
        echo "  backup [name]     Create a backup with optional name"
        echo "  list              List all available backups"
        echo "  cleanup [days]    Remove backups older than X days (default: 30)"
        echo "  test              Test database connection"
        echo "  restore <file>    Restore from backup file"
        echo ""
        echo "Examples:"
        echo "  $0 backup"
        echo "  $0 backup 'before_update'"
        echo "  $0 list"
        echo "  $0 cleanup 7"
        echo "  $0 restore /path/to/backup.sql.gz"
        ;;
esac
EOF

chmod +x /home/shifthandoversajid/scripts/mysql_backup.sh
```

### Step 4: Create Application Backup Script
```bash
cat > /home/shifthandoversajid/scripts/app_backup.sh << 'EOF'
#!/bin/bash

# Full Application Backup Script
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
APP_DIR="/home/shifthandoversajid/shift_handover_app_26102025"
BACKUP_TYPE="${1:-daily}"
BACKUP_DIR="/home/shifthandoversajid/backups/${BACKUP_TYPE}"

# Colors
BLUE='\033[0;34m'
GREEN='\033[0;32m'
NC='\033[0m'

log() { echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1"; }
success() { echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')] SUCCESS:${NC} $1"; }

log "Starting application backup - Type: $BACKUP_TYPE"

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Backup application files
log "Backing up application files..."
tar -czf "${BACKUP_DIR}/app_${TIMESTAMP}.tar.gz" \
    -C "$(dirname "$APP_DIR")" \
    --exclude="*.log" \
    --exclude="__pycache__" \
    --exclude="*.pyc" \
    --exclude=".git" \
    "$(basename "$APP_DIR")"

# Backup database
log "Backing up database..."
/home/shifthandoversajid/scripts/mysql_backup.sh backup "db_${BACKUP_TYPE}_${TIMESTAMP}"

# Create backup manifest
cat > "${BACKUP_DIR}/manifest_${TIMESTAMP}.txt" << MANIFEST
Application Backup Manifest
===========================
Type: $BACKUP_TYPE
Date: $(date)
Hostname: $(hostname)

Files:
$(ls -lh "${BACKUP_DIR}/"*"${TIMESTAMP}"* | awk '{print $9, $5}')

Docker Status:
$(docker ps --format "table {{.Names}}\t{{.Status}}")

Disk Usage:
$(df -h "$BACKUP_DIR" | tail -1)
MANIFEST

success "Backup completed successfully!"
log "Backup location: $BACKUP_DIR"
EOF

chmod +x /home/shifthandoversajid/scripts/app_backup.sh
```

### Step 5: Create Monitoring Script
```bash
cat > /home/shifthandoversajid/scripts/backup_monitor.sh << 'EOF'
#!/bin/bash

# Backup Status Monitor
echo "==================================="
echo "Shift Handover App - Backup Status"
echo "==================================="
echo "Date: $(date)"
echo ""

# Application status
echo "Application Status:"
echo "------------------"
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
echo ""

# Recent backups
echo "Recent Backups:"
echo "--------------"
find /home/shifthandoversajid/backups -name "*.tar.gz" -o -name "*.sql.gz" | \
head -10 | while read backup; do
    echo "$(ls -lh "$backup" | awk '{print $6, $7, $8, $9, $5}')"
done
echo ""

# Disk usage
echo "Backup Disk Usage:"
echo "-----------------"
df -h /home/shifthandoversajid/backups
echo ""

# Recent logs
echo "Recent Backup Activity:"
echo "----------------------"
if [ -f "/home/shifthandoversajid/logs/backup.log" ]; then
    tail -10 /home/shifthandoversajid/logs/backup.log
else
    echo "No backup logs found"
fi
echo ""

# Cron status
echo "Scheduled Backups:"
echo "-----------------"
crontab -l | grep -i backup || echo "No scheduled backups found"
EOF

chmod +x /home/shifthandoversajid/scripts/backup_monitor.sh
```

### Step 6: Test the Backup System
```bash
# Test database connection
/home/shifthandoversajid/scripts/mysql_backup.sh test

# Create test backup
/home/shifthandoversajid/scripts/mysql_backup.sh backup "initial_test"

# List backups
/home/shifthandoversajid/scripts/mysql_backup.sh list

# Check status
/home/shifthandoversajid/scripts/backup_monitor.sh
```

### Step 7: Schedule Automatic Backups
```bash
# Add to crontab
(crontab -l 2>/dev/null; cat << 'CRON'
# Shift Handover Application Backups
# Daily full backup at 2:00 AM
0 2 * * * /home/shifthandoversajid/scripts/app_backup.sh daily >> /home/shifthandoversajid/logs/backup.log 2>&1

# Database backup every 6 hours
0 */6 * * * /home/shifthandoversajid/scripts/mysql_backup.sh backup >> /home/shifthandoversajid/logs/db_backup.log 2>&1

# Weekly backup on Sunday at 3:00 AM
0 3 * * 0 /home/shifthandoversajid/scripts/app_backup.sh weekly >> /home/shifthandoversajid/logs/backup.log 2>&1

# Monthly backup on 1st day at 4:00 AM
0 4 1 * * /home/shifthandoversajid/scripts/app_backup.sh monthly >> /home/shifthandoversajid/logs/backup.log 2>&1

# Cleanup old daily backups (keep 7 days)
0 5 * * * /home/shifthandoversajid/scripts/mysql_backup.sh cleanup 7 >> /home/shifthandoversajid/logs/cleanup.log 2>&1
CRON
) | crontab -

# Verify cron jobs
crontab -l
```

## 🔧 Manual Commands

### Quick Backup Commands
```bash
# Quick database backup
/home/shifthandoversajid/scripts/mysql_backup.sh backup

# Quick application backup
/home/shifthandoversajid/scripts/app_backup.sh daily

# Custom named backup
/home/shifthandoversajid/scripts/mysql_backup.sh backup "before_update"
```

### Monitoring Commands
```bash
# Check backup status
/home/shifthandoversajid/scripts/backup_monitor.sh

# List all backups
/home/shifthandoversajid/scripts/mysql_backup.sh list

# Check logs
tail -f /home/shifthandoversajid/logs/backup.log
```

### Restore Commands
```bash
# List available backups
/home/shifthandoversajid/scripts/mysql_backup.sh list

# Restore database (be careful!)
/home/shifthandoversajid/scripts/mysql_backup.sh restore /path/to/backup.sql.gz
```

## 📊 Backup Schedule

| Type | Schedule | Retention | Description |
|------|----------|-----------|-------------|
| Database | Every 6 hours | 7 days | MySQL dumps |
| Daily App | 2:00 AM daily | 7 days | Full application |
| Weekly App | 3:00 AM Sunday | 30 days | Full application |
| Monthly App | 4:00 AM 1st day | 90 days | Full application |

## 🚨 Important Notes

1. **Test Restore**: Regularly test restore process
2. **Monitor Space**: Watch disk usage in backup directory
3. **Check Logs**: Review backup logs for errors
4. **Security**: Backup files contain sensitive data
5. **Docker**: Ensure containers are running for backups

## 📞 Troubleshooting

### Common Issues

1. **Container Not Running**
   ```bash
   cd /home/shifthandoversajid/shift_handover_app_26102025
   docker-compose up -d
   ```

2. **Permission Denied**
   ```bash
   chmod +x /home/shifthandoversajid/scripts/*.sh
   ```

3. **Disk Space Full**
   ```bash
   # Clean old backups
   /home/shifthandoversajid/scripts/mysql_backup.sh cleanup 3
   ```

4. **Backup Failed**
   ```bash
   # Check container status
   docker ps
   
   # Check logs
   tail -f /home/shifthandoversajid/logs/backup.log
   ```

Your backup system is now ready! 🎉

Next steps:
1. SSH to VM and run the setup commands
2. Test backups with the provided commands
3. Monitor the system using the monitoring script
4. Verify scheduled backups are working