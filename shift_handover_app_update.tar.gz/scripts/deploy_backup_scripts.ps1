# GCP VM Backup Scripts Deployment (PowerShell)
# Usage: .\deploy_backup_scripts.ps1

param(
    [string]$VMUser = "shifthandoversajid",
    [string]$VMIP = "35.200.202.18",
    [string]$SSHKey = "$env:USERPROFILE\.ssh\my-gcp-key"
)

# Configuration
$AppDir = "/home/shifthandoversajid/shift_handover_app_26102025"
$ScriptsDir = "/home/shifthandoversajid/scripts"

# Colors for output
function Write-ColorOutput($ForegroundColor) {
    $fc = $host.UI.RawUI.ForegroundColor
    $host.UI.RawUI.ForegroundColor = $ForegroundColor
    if ($args) {
        Write-Output $args
    } else {
        $input | Write-Output
    }
    $host.UI.RawUI.ForegroundColor = $fc
}

function Log($Message) {
    Write-ColorOutput Blue "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $Message"
}

function Success($Message) {
    Write-ColorOutput Green "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] SUCCESS: $Message"
}

function Warning($Message) {
    Write-ColorOutput Yellow "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] WARNING: $Message"
}

function Error($Message) {
    Write-ColorOutput Red "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] ERROR: $Message"
}

# Check prerequisites
function Test-Prerequisites {
    Log "Checking prerequisites..."
    
    # Check if SSH key exists
    if (-not (Test-Path $SSHKey)) {
        Error "SSH key not found: $SSHKey"
        exit 1
    }
    
    # Check if backup scripts exist
    if (-not (Test-Path "backup_application.sh") -or -not (Test-Path "db_backup.sh")) {
        Error "Backup scripts not found in current directory"
        exit 1
    }
    
    # Check if ssh command is available
    try {
        ssh -V | Out-Null
    } catch {
        Error "SSH command not found. Please install OpenSSH or Git for Windows"
        exit 1
    }
    
    Success "Prerequisites checked"
}

# Test SSH connection
function Test-SSHConnection {
    Log "Testing SSH connection to $VMUser@$VMIP..."
    
    try {
        $result = ssh -i $SSHKey -o ConnectTimeout=10 -o StrictHostKeyChecking=no "$VMUser@$VMIP" "echo 'SSH connection successful'" 2>$null
        if ($result -eq "SSH connection successful") {
            Success "SSH connection successful"
        } else {
            throw "Connection failed"
        }
    } catch {
        Error "Cannot connect to VM via SSH"
        exit 1
    }
}

# Create directories on VM
function New-VMDirectories {
    Log "Creating directories on VM..."
    
    $commands = @"
mkdir -p /home/shifthandoversajid/scripts
mkdir -p /home/shifthandoversajid/backups/{daily,weekly,monthly}
mkdir -p /home/shifthandoversajid/backups/database
mkdir -p /home/shifthandoversajid/logs
chmod 755 /home/shifthandoversajid/scripts
chmod 755 /home/shifthandoversajid/backups
chmod 755 /home/shifthandoversajid/logs
echo 'Directories created successfully'
"@
    
    ssh -i $SSHKey "$VMUser@$VMIP" $commands
    Success "Directories created on VM"
}

# Upload backup scripts
function Copy-BackupScripts {
    Log "Uploading backup scripts to VM..."
    
    # Upload scripts using scp
    scp -i $SSHKey "backup_application.sh" "$VMUser@$VMIP`:$ScriptsDir/"
    scp -i $SSHKey "db_backup.sh" "$VMUser@$VMIP`:$ScriptsDir/"
    
    # Make scripts executable
    ssh -i $SSHKey "$VMUser@$VMIP" "chmod +x $ScriptsDir/backup_application.sh"
    ssh -i $SSHKey "$VMUser@$VMIP" "chmod +x $ScriptsDir/db_backup.sh"
    
    Success "Backup scripts uploaded and configured"
}

# Create backup configuration
function New-BackupConfig {
    Log "Creating backup configuration..."
    
    $configContent = @"
# Backup Configuration
APP_DIR="/home/shifthandoversajid/shift_handover_app_26102025"
BACKUP_BASE_DIR="/home/shifthandoversajid/backups"

# Retention settings (days)
DAILY_RETENTION=7
WEEKLY_RETENTION=30
MONTHLY_RETENTION=90

# Email notifications (optional)
NOTIFY_EMAIL=""
SMTP_SERVER=""
SMTP_PORT=""
SMTP_USER=""
SMTP_PASSWORD=""

# Slack notifications (optional)
SLACK_WEBHOOK=""
SLACK_CHANNEL=""
"@

    $commands = @"
cat > /home/shifthandoversajid/scripts/backup_config.conf << 'EOF'
$configContent
EOF
echo 'Backup configuration created'
"@
    
    ssh -i $SSHKey "$VMUser@$VMIP" $commands
    Success "Backup configuration created"
}

# Setup cron jobs
function Set-CronJobs {
    Log "Setting up automated backup cron jobs..."
    
    $cronCommands = @"
(crontab -l 2>/dev/null || echo "") | grep -v "backup_application.sh\|db_backup.sh" > /tmp/current_cron
cat >> /tmp/current_cron << 'CRON'
# Shift Handover Application Backups
# Daily backup at 2:00 AM
0 2 * * * /home/shifthandoversajid/scripts/backup_application.sh daily >> /home/shifthandoversajid/logs/backup.log 2>&1

# Weekly backup on Sunday at 3:00 AM
0 3 * * 0 /home/shifthandoversajid/scripts/backup_application.sh weekly >> /home/shifthandoversajid/logs/backup.log 2>&1

# Monthly backup on 1st day at 4:00 AM
0 4 1 * * /home/shifthandoversajid/scripts/backup_application.sh monthly >> /home/shifthandoversajid/logs/backup.log 2>&1

# Database backup every 6 hours
0 */6 * * * /home/shifthandoversajid/scripts/db_backup.sh backup >> /home/shifthandoversajid/logs/db_backup.log 2>&1

# Cleanup old backups daily at 5:00 AM
0 5 * * * /home/shifthandoversajid/scripts/db_backup.sh cleanup 30 >> /home/shifthandoversajid/logs/cleanup.log 2>&1
CRON
crontab /tmp/current_cron
rm /tmp/current_cron
echo 'Cron jobs configured successfully'
crontab -l
"@
    
    ssh -i $SSHKey "$VMUser@$VMIP" $cronCommands
    Success "Automated backup cron jobs configured"
}

# Create monitoring script
function New-MonitoringScript {
    Log "Creating backup monitoring script..."
    
    $monitorScript = @"
#!/bin/bash

# Backup Monitoring Script
BACKUP_DIR="/home/shifthandoversajid/backups"
LOG_DIR="/home/shifthandoversajid/logs"

echo "Shift Handover Application - Backup Status"
echo "=========================================="
echo "Date: `$(date)"
echo ""

# Check recent backups
echo "Recent Backups:"
echo "---------------"
find "`$BACKUP_DIR" -name "*.tar.gz" -o -name "*.sql.gz" | head -10 | while read backup; do
    echo "`$(ls -lh "`$backup" | awk '{print `$6, `$7, `$8, `$9, `$5}')"
done
echo ""

# Check disk usage
echo "Disk Usage:"
echo "-----------"
df -h "`$BACKUP_DIR"
echo ""

# Check backup logs
echo "Recent Backup Activity:"
echo "----------------------"
if [ -f "`$LOG_DIR/backup.log" ]; then
    tail -20 "`$LOG_DIR/backup.log"
else
    echo "No backup log found"
fi
echo ""

# Check cron status
echo "Scheduled Backups:"
echo "------------------"
crontab -l | grep backup || echo "No scheduled backups found"
echo ""

# Check database connection
echo "Database Status:"
echo "---------------"
if command -v docker &>/dev/null && docker ps | grep -q postgres; then
    echo "✓ PostgreSQL container is running"
    CONTAINER=`$(docker ps --format "{{.Names}}" | grep postgres | head -1)
    echo "Container: `$CONTAINER"
else
    echo "⚠ PostgreSQL container not found"
fi
"@

    $commands = @"
cat > /home/shifthandoversajid/scripts/backup_monitor.sh << 'EOF'
$monitorScript
EOF
chmod +x /home/shifthandoversajid/scripts/backup_monitor.sh
echo 'Backup monitoring script created'
"@
    
    ssh -i $SSHKey "$VMUser@$VMIP" $commands
    Success "Backup monitoring script created"
}

# Test backup functionality
function Test-BackupFunctionality {
    Log "Testing backup functionality..."
    
    $testCommands = @"
echo 'Testing database backup...'
cd /home/shifthandoversajid/scripts
./db_backup.sh test
./db_backup.sh backup "test_deployment_backup"
./db_backup.sh list
echo ''
echo 'Backup test completed successfully!'
"@
    
    ssh -i $SSHKey "$VMUser@$VMIP" $testCommands
    Success "Backup functionality tested successfully"
}

# Create deployment summary
function New-DeploymentSummary {
    Log "Creating deployment summary..."
    
    $summaryContent = @"
# Backup System Deployment Summary

## 📁 Backup Scripts Installed

### 🔧 Scripts Location: ``/home/shifthandoversajid/scripts/``
- ``backup_application.sh`` - Complete application backup
- ``db_backup.sh`` - Database backup and restore
- ``backup_monitor.sh`` - Backup status monitoring
- ``backup_config.conf`` - Configuration file

### 💾 Backup Storage: ``/home/shifthandoversajid/backups/``
- ``daily/`` - Daily backups (7 days retention)
- ``weekly/`` - Weekly backups (30 days retention)
- ``monthly/`` - Monthly backups (90 days retention)
- ``database/`` - Database backups

### 📊 Logs: ``/home/shifthandoversajid/logs/``
- ``backup.log`` - Application backup logs
- ``db_backup.log`` - Database backup logs
- ``cleanup.log`` - Cleanup operation logs

## ⏰ Automated Schedule

```
Daily backup:     2:00 AM (full application)
Weekly backup:    3:00 AM Sunday (full application)
Monthly backup:   4:00 AM 1st day (full application)
Database backup:  Every 6 hours
Cleanup:          5:00 AM daily (removes old backups)
```

## 🔧 Manual Operations

### Create Backup
```bash
# Full application backup
./scripts/backup_application.sh daily

# Database only backup
./scripts/db_backup.sh backup

# Custom named backup
./scripts/db_backup.sh backup "before_update"
```

### Restore Database
```bash
# List available backups
./scripts/db_backup.sh list

# Restore from backup
./scripts/db_backup.sh restore /path/to/backup.sql.gz
```

### Monitor Status
```bash
# Check backup status
./scripts/backup_monitor.sh

# View logs
tail -f logs/backup.log
tail -f logs/db_backup.log
```

### Cleanup Old Backups
```bash
# Remove backups older than 30 days
./scripts/db_backup.sh cleanup 30
```

## 🚨 Important Notes

1. **Database Connection**: Scripts auto-detect Docker or local PostgreSQL
2. **Permissions**: All scripts have execute permissions
3. **Logs**: Check logs regularly for backup status
4. **Storage**: Monitor disk space in backup directory
5. **Testing**: Test restore process periodically

Deployment completed successfully! 🎉
"@

    $commands = @"
cat > /home/shifthandoversajid/BACKUP_DEPLOYMENT_SUMMARY.md << 'EOF'
$summaryContent
EOF
echo 'Deployment summary created at /home/shifthandoversajid/BACKUP_DEPLOYMENT_SUMMARY.md'
"@
    
    ssh -i $SSHKey "$VMUser@$VMIP" $commands
    Success "Deployment summary created"
}

# Main deployment process
function Start-Deployment {
    Log "Starting backup scripts deployment to GCP VM..."
    
    Test-Prerequisites
    Test-SSHConnection
    New-VMDirectories
    Copy-BackupScripts
    New-BackupConfig
    Set-CronJobs
    New-MonitoringScript
    Test-BackupFunctionality
    New-DeploymentSummary
    
    Success "Backup system deployment completed successfully!"
    
    Write-Host ""
    Write-Host "🎉 Deployment Summary:" -ForegroundColor Green
    Write-Host "======================" -ForegroundColor Green
    Write-Host "VM: $VMUser@$VMIP"
    Write-Host "Scripts: $ScriptsDir"
    Write-Host "Backups: /home/shifthandoversajid/backups"
    Write-Host "Logs: /home/shifthandoversajid/logs"
    Write-Host ""
    Write-Host "Next steps:"
    Write-Host "1. SSH to VM: ssh -i $SSHKey $VMUser@$VMIP"
    Write-Host "2. Check status: ./scripts/backup_monitor.sh"
    Write-Host "3. Test backup: ./scripts/db_backup.sh backup test"
    Write-Host "4. View summary: cat BACKUP_DEPLOYMENT_SUMMARY.md"
}

# Error handling
trap {
    Error "Deployment failed: $($_.Exception.Message)"
    exit 1
}

# Run main function
Start-Deployment