#!/bin/bash

# ========================================
# GCP VM Deployment Script for Shift Handover App
# ========================================
# This script deploys the backup scripts to your GCP VM
# Usage: ./deploy_backup_scripts.sh

set -euo pipefail

# GCP VM Configuration
VM_IP="35.200.202.18"
VM_USER="shifthandoversajid"
SSH_KEY="~/.ssh/my-gcp-key"
APP_DIR="/home/shifthandoversajid/shift_handover_app_26102025"
SCRIPTS_DIR="/home/shifthandoversajid/scripts"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log() { echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1"; }
error() { echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')] ERROR:${NC} $1" >&2; }
success() { echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')] SUCCESS:${NC} $1"; }
warning() { echo -e "${YELLOW}[$(date '+%Y-%m-%d %H:%M:%S')] WARNING:${NC} $1"; }

# Check prerequisites
check_prerequisites() {
    log "Checking prerequisites..."
    
    # Check if SSH key exists
    if [ ! -f "${SSH_KEY/#\~/$HOME}" ]; then
        error "SSH key not found: $SSH_KEY"
        exit 1
    fi
    
    # Check if backup scripts exist locally
    if [ ! -f "scripts/backup_application.sh" ] || [ ! -f "scripts/db_backup.sh" ]; then
        error "Backup scripts not found in local scripts/ directory"
        exit 1
    fi
    
    success "Prerequisites checked"
}

# Test SSH connection
test_ssh_connection() {
    log "Testing SSH connection to $VM_USER@$VM_IP..."
    
    if ssh -i "${SSH_KEY/#\~/$HOME}" -o ConnectTimeout=10 -o StrictHostKeyChecking=no "$VM_USER@$VM_IP" "echo 'SSH connection successful'" &>/dev/null; then
        success "SSH connection successful"
    else
        error "Cannot connect to VM via SSH"
        exit 1
    fi
}

# Create directories on VM
create_vm_directories() {
    log "Creating directories on VM..."
    
    ssh -i "${SSH_KEY/#\~/$HOME}" "$VM_USER@$VM_IP" << 'EOF'
# Create scripts directory
mkdir -p /home/shifthandoversajid/scripts
mkdir -p /home/shifthandoversajid/backups/{daily,weekly,monthly}
mkdir -p /home/shifthandoversajid/backups/database
mkdir -p /home/shifthandoversajid/logs

# Set permissions
chmod 755 /home/shifthandoversajid/scripts
chmod 755 /home/shifthandoversajid/backups
chmod 755 /home/shifthandoversajid/logs

echo "Directories created successfully"
EOF
    
    success "Directories created on VM"
}

# Upload backup scripts
upload_scripts() {
    log "Uploading backup scripts to VM..."
    
    # Upload backup scripts
    scp -i "${SSH_KEY/#\~/$HOME}" scripts/backup_application.sh "$VM_USER@$VM_IP:$SCRIPTS_DIR/"
    scp -i "${SSH_KEY/#\~/$HOME}" scripts/db_backup.sh "$VM_USER@$VM_IP:$SCRIPTS_DIR/"
    
    # Make scripts executable
    ssh -i "${SSH_KEY/#\~/$HOME}" "$VM_USER@$VM_IP" << EOF
chmod +x $SCRIPTS_DIR/backup_application.sh
chmod +x $SCRIPTS_DIR/db_backup.sh
EOF
    
    success "Backup scripts uploaded and configured"
}

# Create backup configuration
create_backup_config() {
    log "Creating backup configuration..."
    
    ssh -i "${SSH_KEY/#\~/$HOME}" "$VM_USER@$VM_IP" << 'EOF'
# Create backup configuration file
cat > /home/shifthandoversajid/scripts/backup_config.conf << 'CONFIG'
# Backup Configuration
APP_DIR="/home/shifthandoversajid/shift_handover_app_26102025"
BACKUP_BASE_DIR="/home/shifthandoversajid/backups"

# Retention settings (days)
DAILY_RETENTION=7
WEEKLY_RETENTION=30
MONTHLY_RETENTION=90

# Email notifications (optional)
NOTIFY_EMAIL=""
SMTP_SERVER=""
SMTP_PORT=""
SMTP_USER=""
SMTP_PASSWORD=""

# Slack notifications (optional)
SLACK_WEBHOOK=""
SLACK_CHANNEL=""
CONFIG

echo "Backup configuration created"
EOF
    
    success "Backup configuration created"
}

# Setup cron jobs
setup_cron_jobs() {
    log "Setting up automated backup cron jobs..."
    
    ssh -i "${SSH_KEY/#\~/$HOME}" "$VM_USER@$VM_IP" << 'EOF'
# Create cron jobs for automated backups
(crontab -l 2>/dev/null || echo "") | grep -v "backup_application.sh\|db_backup.sh" > /tmp/current_cron

# Add backup cron jobs
cat >> /tmp/current_cron << 'CRON'
# Shift Handover Application Backups
# Daily backup at 2:00 AM
0 2 * * * /home/shifthandoversajid/scripts/backup_application.sh daily >> /home/shifthandoversajid/logs/backup.log 2>&1

# Weekly backup on Sunday at 3:00 AM
0 3 * * 0 /home/shifthandoversajid/scripts/backup_application.sh weekly >> /home/shifthandoversajid/logs/backup.log 2>&1

# Monthly backup on 1st day at 4:00 AM
0 4 1 * * /home/shifthandoversajid/scripts/backup_application.sh monthly >> /home/shifthandoversajid/logs/backup.log 2>&1

# Database backup every 6 hours
0 */6 * * * /home/shifthandoversajid/scripts/db_backup.sh backup >> /home/shifthandoversajid/logs/db_backup.log 2>&1

# Cleanup old backups daily at 5:00 AM
0 5 * * * /home/shifthandoversajid/scripts/db_backup.sh cleanup 30 >> /home/shifthandoversajid/logs/cleanup.log 2>&1
CRON

# Install new crontab
crontab /tmp/current_cron

# Clean up
rm /tmp/current_cron

echo "Cron jobs configured successfully"
crontab -l
EOF
    
    success "Automated backup cron jobs configured"
}

# Create monitoring script
create_monitoring_script() {
    log "Creating backup monitoring script..."
    
    ssh -i "${SSH_KEY/#\~/$HOME}" "$VM_USER@$VM_IP" << 'EOF'
cat > /home/shifthandoversajid/scripts/backup_monitor.sh << 'MONITOR'
#!/bin/bash

# Backup Monitoring Script
# Usage: ./backup_monitor.sh

BACKUP_DIR="/home/shifthandoversajid/backups"
LOG_DIR="/home/shifthandoversajid/logs"

echo "Shift Handover Application - Backup Status"
echo "=========================================="
echo "Date: $(date)"
echo ""

# Check recent backups
echo "Recent Backups:"
echo "---------------"
find "$BACKUP_DIR" -name "*.tar.gz" -o -name "*.sql.gz" | head -10 | while read backup; do
    echo "$(ls -lh "$backup" | awk '{print $6, $7, $8, $9, $5}')"
done
echo ""

# Check disk usage
echo "Disk Usage:"
echo "-----------"
df -h "$BACKUP_DIR"
echo ""

# Check backup logs
echo "Recent Backup Activity:"
echo "----------------------"
if [ -f "$LOG_DIR/backup.log" ]; then
    tail -20 "$LOG_DIR/backup.log"
else
    echo "No backup log found"
fi
echo ""

# Check cron status
echo "Scheduled Backups:"
echo "------------------"
crontab -l | grep backup || echo "No scheduled backups found"
echo ""

# Check database connection
echo "Database Status:"
echo "---------------"
if command -v docker &>/dev/null && docker ps | grep -q postgres; then
    echo "✓ PostgreSQL container is running"
    CONTAINER=$(docker ps --format "{{.Names}}" | grep postgres | head -1)
    echo "Container: $CONTAINER"
else
    echo "⚠ PostgreSQL container not found"
fi
MONITOR

chmod +x /home/shifthandoversajid/scripts/backup_monitor.sh
echo "Backup monitoring script created"
EOF
    
    success "Backup monitoring script created"
}

# Test backup functionality
test_backup_functionality() {
    log "Testing backup functionality..."
    
    ssh -i "${SSH_KEY/#\~/$HOME}" "$VM_USER@$VM_IP" << 'EOF'
echo "Testing database backup..."
cd /home/shifthandoversajid/scripts

# Test database connection
./db_backup.sh test

# Create a test backup
./db_backup.sh backup "test_deployment_backup"

# List backups
./db_backup.sh list

echo ""
echo "Backup test completed successfully!"
EOF
    
    success "Backup functionality tested successfully"
}

# Create deployment summary
create_deployment_summary() {
    log "Creating deployment summary..."
    
    ssh -i "${SSH_KEY/#\~/$HOME}" "$VM_USER@$VM_IP" << 'EOF'
cat > /home/shifthandoversajid/BACKUP_DEPLOYMENT_SUMMARY.md << 'SUMMARY'
# Backup System Deployment Summary

## 📁 Backup Scripts Installed

### 🔧 Scripts Location: `/home/shifthandoversajid/scripts/`
- `backup_application.sh` - Complete application backup
- `db_backup.sh` - Database backup and restore
- `backup_monitor.sh` - Backup status monitoring
- `backup_config.conf` - Configuration file

### 💾 Backup Storage: `/home/shifthandoversajid/backups/`
- `daily/` - Daily backups (7 days retention)
- `weekly/` - Weekly backups (30 days retention)
- `monthly/` - Monthly backups (90 days retention)
- `database/` - Database backups

### 📊 Logs: `/home/shifthandoversajid/logs/`
- `backup.log` - Application backup logs
- `db_backup.log` - Database backup logs
- `cleanup.log` - Cleanup operation logs

## ⏰ Automated Schedule

```
Daily backup:     2:00 AM (full application)
Weekly backup:    3:00 AM Sunday (full application)
Monthly backup:   4:00 AM 1st day (full application)
Database backup:  Every 6 hours
Cleanup:          5:00 AM daily (removes old backups)
```

## 🔧 Manual Operations

### Create Backup
```bash
# Full application backup
./scripts/backup_application.sh daily

# Database only backup
./scripts/db_backup.sh backup

# Custom named backup
./scripts/db_backup.sh backup "before_update"
```

### Restore Database
```bash
# List available backups
./scripts/db_backup.sh list

# Restore from backup
./scripts/db_backup.sh restore /path/to/backup.sql.gz
```

### Monitor Status
```bash
# Check backup status
./scripts/backup_monitor.sh

# View logs
tail -f logs/backup.log
tail -f logs/db_backup.log
```

### Cleanup Old Backups
```bash
# Remove backups older than 30 days
./scripts/db_backup.sh cleanup 30
```

## 🚨 Important Notes

1. **Database Connection**: Scripts auto-detect Docker or local PostgreSQL
2. **Permissions**: All scripts have execute permissions
3. **Logs**: Check logs regularly for backup status
4. **Storage**: Monitor disk space in backup directory
5. **Testing**: Test restore process periodically

## 📞 Troubleshooting

### Check Database Connection
```bash
./scripts/db_backup.sh test
```

### View Cron Jobs
```bash
crontab -l
```

### Check Script Permissions
```bash
ls -la scripts/
```

Deployment completed successfully! 🎉
SUMMARY

echo "Deployment summary created at /home/shifthandoversajid/BACKUP_DEPLOYMENT_SUMMARY.md"
EOF
    
    success "Deployment summary created"
}

# Main deployment process
main() {
    log "Starting backup scripts deployment to GCP VM..."
    
    check_prerequisites
    test_ssh_connection
    create_vm_directories
    upload_scripts
    create_backup_config
    setup_cron_jobs
    create_monitoring_script
    test_backup_functionality
    create_deployment_summary
    
    success "Backup system deployment completed successfully!"
    
    echo ""
    echo "🎉 Deployment Summary:"
    echo "======================"
    echo "VM: $VM_USER@$VM_IP"
    echo "Scripts: $SCRIPTS_DIR"
    echo "Backups: /home/shifthandoversajid/backups"
    echo "Logs: /home/shifthandoversajid/logs"
    echo ""
    echo "Next steps:"
    echo "1. SSH to VM: ssh -i $SSH_KEY $VM_USER@$VM_IP"
    echo "2. Check status: ./scripts/backup_monitor.sh"
    echo "3. Test backup: ./scripts/db_backup.sh backup test"
    echo "4. View summary: cat BACKUP_DEPLOYMENT_SUMMARY.md"
}

# Error handling
trap 'error "Deployment failed at line $LINENO"' ERR

# Run main function
main "$@"