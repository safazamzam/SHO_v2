#!/bin/bash

# ========================================
# Database Backup and Restore Script
# ========================================
# Comprehensive database backup and restore utility
# Usage: ./db_backup.sh [command] [options]
# Commands: backup, restore, list, cleanup, schedule

set -euo pipefail

# Configuration
APP_DIR="/home/shifthandoversajid/shift_handover_app_26102025"
DB_BACKUP_DIR="/home/shifthandoversajid/backups/database"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

# Default retention (days)
DEFAULT_RETENTION=30

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Logging functions
log() { echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1"; }
error() { echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')] ERROR:${NC} $1" >&2; }
success() { echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')] SUCCESS:${NC} $1"; }
warning() { echo -e "${YELLOW}[$(date '+%Y-%m-%d %H:%M:%S')] WARNING:${NC} $1"; }

# Load database configuration
load_db_config() {
    log "Loading database configuration..."
    
    # Try to load from environment files
    if [ -f "$APP_DIR/.env.production" ]; then
        source "$APP_DIR/.env.production"
        log "Loaded production environment"
    elif [ -f "$APP_DIR/.env" ]; then
        source "$APP_DIR/.env"
        log "Loaded development environment"
    else
        warning "No environment file found, using defaults"
    fi
    
    # Set defaults if not found in environment
    export DB_NAME="${DATABASE_NAME:-shift_handover}"
    export DB_USER="${DATABASE_USER:-postgres}"
    export DB_HOST="${DATABASE_HOST:-localhost}"
    export DB_PORT="${DATABASE_PORT:-5432}"
    export DB_PASSWORD="${DATABASE_PASSWORD:-}"
    
    log "Database: $DB_NAME@$DB_HOST:$DB_PORT as $DB_USER"
}

# Check database connection
check_db_connection() {
    log "Checking database connection..."
    
    # Check if Docker container is running
    if docker ps --format "{{.Names}}" | grep -q postgres; then
        POSTGRES_CONTAINER=$(docker ps --format "{{.Names}}" | grep postgres | head -1)
        
        if docker exec "$POSTGRES_CONTAINER" pg_isready -U "$DB_USER" -d "$DB_NAME" &>/dev/null; then
            success "Database connection successful (Docker)"
            export CONNECTION_TYPE="docker"
            export POSTGRES_CONTAINER
            return 0
        fi
    fi
    
    # Check local PostgreSQL
    if command -v pg_isready &>/dev/null; then
        if PGPASSWORD="$DB_PASSWORD" pg_isready -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" &>/dev/null; then
            success "Database connection successful (Local)"
            export CONNECTION_TYPE="local"
            return 0
        fi
    fi
    
    error "Cannot connect to database"
    return 1
}

# Create database backup
backup_database() {
    local backup_name="${1:-db_backup_${TIMESTAMP}}"
    local backup_file="${DB_BACKUP_DIR}/${backup_name}.sql"
    
    log "Creating database backup: $backup_name"
    
    # Create backup directory
    mkdir -p "$DB_BACKUP_DIR"
    
    # Perform backup based on connection type
    case "$CONNECTION_TYPE" in
        docker)
            log "Using Docker container for backup"
            docker exec "$POSTGRES_CONTAINER" pg_dump -U "$DB_USER" -d "$DB_NAME" \
                --verbose --no-password --format=plain --no-privileges --no-tablespaces \
                > "$backup_file"
            ;;
        local)
            log "Using local PostgreSQL for backup"
            PGPASSWORD="$DB_PASSWORD" pg_dump -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
                --verbose --no-password --format=plain --no-privileges --no-tablespaces \
                > "$backup_file"
            ;;
        *)
            error "Unknown connection type: $CONNECTION_TYPE"
            return 1
            ;;
    esac
    
    # Compress backup
    log "Compressing backup..."
    gzip "$backup_file"
    backup_file="${backup_file}.gz"
    
    # Create backup metadata
    cat > "${backup_file}.info" << EOF
Backup Information
==================
Database: $DB_NAME
Host: $DB_HOST:$DB_PORT
User: $DB_USER
Timestamp: $TIMESTAMP
Date: $(date)
Connection: $CONNECTION_TYPE
Size: $(ls -lh "$backup_file" | awk '{print $5}')
Checksum: $(md5sum "$backup_file" | awk '{print $1}')
EOF
    
    success "Database backup completed: $backup_file"
    log "Backup size: $(ls -lh "$backup_file" | awk '{print $5}')"
}

# Restore database from backup
restore_database() {
    local backup_file="$1"
    local confirm="${2:-false}"
    
    if [ ! -f "$backup_file" ]; then
        error "Backup file not found: $backup_file"
        return 1
    fi
    
    log "Preparing to restore database from: $backup_file"
    
    # Safety confirmation
    if [ "$confirm" != "yes" ]; then
        warning "This will REPLACE the current database!"
        echo -n "Are you sure you want to continue? Type 'yes' to confirm: "
        read -r confirmation
        if [ "$confirmation" != "yes" ]; then
            log "Restore cancelled by user"
            return 1
        fi
    fi
    
    # Create temporary restore file
    local temp_file="/tmp/restore_${TIMESTAMP}.sql"
    
    # Decompress if needed
    if [[ "$backup_file" == *.gz ]]; then
        log "Decompressing backup file..."
        gunzip -c "$backup_file" > "$temp_file"
    else
        cp "$backup_file" "$temp_file"
    fi
    
    log "Starting database restore..."
    
    # Perform restore based on connection type
    case "$CONNECTION_TYPE" in
        docker)
            log "Using Docker container for restore"
            # Drop and recreate database
            docker exec "$POSTGRES_CONTAINER" psql -U "$DB_USER" -c "DROP DATABASE IF EXISTS $DB_NAME;"
            docker exec "$POSTGRES_CONTAINER" psql -U "$DB_USER" -c "CREATE DATABASE $DB_NAME;"
            
            # Restore data
            docker exec -i "$POSTGRES_CONTAINER" psql -U "$DB_USER" -d "$DB_NAME" < "$temp_file"
            ;;
        local)
            log "Using local PostgreSQL for restore"
            # Drop and recreate database
            PGPASSWORD="$DB_PASSWORD" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -c "DROP DATABASE IF EXISTS $DB_NAME;"
            PGPASSWORD="$DB_PASSWORD" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -c "CREATE DATABASE $DB_NAME;"
            
            # Restore data
            PGPASSWORD="$DB_PASSWORD" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" < "$temp_file"
            ;;
    esac
    
    # Cleanup
    rm -f "$temp_file"
    
    success "Database restore completed successfully"
}

# List available backups
list_backups() {
    log "Available database backups:"
    echo
    
    if [ ! -d "$DB_BACKUP_DIR" ] || [ -z "$(ls -A "$DB_BACKUP_DIR" 2>/dev/null)" ]; then
        warning "No backups found in $DB_BACKUP_DIR"
        return 0
    fi
    
    echo "Date Created        Size    File"
    echo "=================== ======= =========================="
    
    for backup in "$DB_BACKUP_DIR"/*.sql.gz; do
        if [ -f "$backup" ]; then
            local date_created=$(stat -c %y "$backup" | cut -d' ' -f1,2 | cut -d'.' -f1)
            local size=$(ls -lh "$backup" | awk '{print $5}')
            local filename=$(basename "$backup")
            
            printf "%-19s %-7s %s\n" "$date_created" "$size" "$filename"
            
            # Show additional info if available
            if [ -f "${backup}.info" ]; then
                echo "    Info: $(grep "Date:" "${backup}.info" | cut -d' ' -f2-)"
            fi
        fi
    done
    echo
}

# Cleanup old backups
cleanup_backups() {
    local retention_days="${1:-$DEFAULT_RETENTION}"
    
    log "Cleaning up backups older than $retention_days days..."
    
    if [ ! -d "$DB_BACKUP_DIR" ]; then
        warning "Backup directory not found: $DB_BACKUP_DIR"
        return 0
    fi
    
    local count=0
    while IFS= read -r -d '' backup; do
        rm -f "$backup" "${backup}.info" 2>/dev/null || true
        ((count++))
    done < <(find "$DB_BACKUP_DIR" -name "*.sql.gz" -mtime +$retention_days -print0 2>/dev/null)
    
    if [ $count -eq 0 ]; then
        log "No old backups found to clean up"
    else
        success "Cleaned up $count old backup(s)"
    fi
}

# Schedule automatic backups
schedule_backups() {
    log "Setting up automatic backup schedule..."
    
    # Create crontab entry
    local cron_entry="0 2 * * * $PWD/$(basename "$0") backup >/var/log/db_backup.log 2>&1"
    
    # Check if cron entry already exists
    if crontab -l 2>/dev/null | grep -q "$(basename "$0")"; then
        warning "Backup schedule already exists"
        crontab -l 2>/dev/null | grep "$(basename "$0")"
        return 0
    fi
    
    # Add to crontab
    (crontab -l 2>/dev/null; echo "$cron_entry") | crontab -
    
    success "Automatic backup scheduled for 2:00 AM daily"
    log "Logs will be written to /var/log/db_backup.log"
}

# Show usage
show_usage() {
    cat << EOF
Database Backup and Restore Script
==================================

Usage: $0 [command] [options]

Commands:
  backup [name]           Create a database backup with optional name
  restore <backup_file>   Restore database from backup file
  list                    List available backups
  cleanup [days]          Remove backups older than specified days (default: $DEFAULT_RETENTION)
  schedule                Set up automatic daily backups via cron
  test                    Test database connection

Examples:
  $0 backup                           # Create backup with timestamp
  $0 backup "before_update"           # Create backup with custom name
  $0 restore db_backup_20241026.sql.gz  # Restore from specific backup
  $0 list                             # Show all available backups
  $0 cleanup 7                        # Remove backups older than 7 days
  $0 schedule                         # Set up daily automatic backups

Environment:
  App Directory: $APP_DIR
  Backup Directory: $DB_BACKUP_DIR
EOF
}

# Main function
main() {
    local command="${1:-}"
    
    case "$command" in
        backup)
            load_db_config
            check_db_connection
            backup_database "$2"
            ;;
        restore)
            if [ -z "${2:-}" ]; then
                error "Backup file path required for restore"
                show_usage
                exit 1
            fi
            load_db_config
            check_db_connection
            restore_database "$2" "${3:-}"
            ;;
        list)
            list_backups
            ;;
        cleanup)
            cleanup_backups "${2:-$DEFAULT_RETENTION}"
            ;;
        schedule)
            schedule_backups
            ;;
        test)
            load_db_config
            check_db_connection
            success "Database connection test passed"
            ;;
        ""|help|--help|-h)
            show_usage
            ;;
        *)
            error "Unknown command: $command"
            show_usage
            exit 1
            ;;
    esac
}

# Error handling
trap 'error "Script failed at line $LINENO"' ERR

# Run main function
main "$@"