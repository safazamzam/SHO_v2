#!/bin/bash

# Simple MySQL Backup Script for Shift Handover App
# This script works directly with the Docker container

TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_DIR="/home/shifthandoversajid/backups/database"
CONTAINER_NAME="shift_handover_app_db_1"
DB_NAME="shift_handover"
DB_USER="user"
DB_PASS="password"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

log() { echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1"; }
success() { echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')] SUCCESS:${NC} $1"; }
error() { echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')] ERROR:${NC} $1" >&2; }
warning() { echo -e "${YELLOW}[$(date '+%Y-%m-%d %H:%M:%S')] WARNING:${NC} $1"; }

# Check if container is running
check_container() {
    log "Checking MySQL container status..."
    
    if ! docker ps | grep -q "$CONTAINER_NAME"; then
        error "MySQL container '$CONTAINER_NAME' is not running"
        log "Try starting it with: cd /home/shifthandoversajid/shift_handover_app_26102025 && docker-compose up -d"
        return 1
    fi
    
    success "MySQL container is running"
    return 0
}

# Test database connection
test_connection() {
    log "Testing database connection..."
    
    check_container || return 1
    
    if docker exec "$CONTAINER_NAME" mysql -u "$DB_USER" -p"$DB_PASS" -e "SELECT 1;" &>/dev/null; then
        success "Database connection successful"
        return 0
    else
        error "Database connection failed"
        return 1
    fi
}

# Create backup
backup_mysql() {
    local backup_name="${1:-backup_${TIMESTAMP}}"
    local backup_file="${BACKUP_DIR}/${backup_name}.sql"
    
    log "Creating MySQL backup: $backup_name"
    
    # Check container and connection
    check_container || return 1
    
    # Create backup directory
    mkdir -p "$BACKUP_DIR"
    
    log "Dumping database '$DB_NAME'..."
    
    # Create backup with warning suppression
    if docker exec "$CONTAINER_NAME" mysqldump -u "$DB_USER" -p"$DB_PASS" \
        --single-transaction --routines --triggers \
        --databases "$DB_NAME" > "$backup_file" 2>/dev/null; then
        
        # Compress backup
        log "Compressing backup..."
        gzip "$backup_file"
        backup_file="${backup_file}.gz"
        
        # Create metadata file
        cat > "${backup_file}.info" << EOF
Backup Information
==================
Name: $backup_name
Date: $(date)
Database: $DB_NAME
Container: $CONTAINER_NAME
Size: $(ls -lh "$backup_file" | awk '{print $5}')
MD5: $(md5sum "$backup_file" | awk '{print $1}')
EOF
        
        success "Backup completed successfully!"
        success "File: $backup_file"
        success "Size: $(ls -lh "$backup_file" | awk '{print $5}')"
        
        return 0
    else
        error "Database backup failed"
        return 1
    fi
}

# List available backups
list_backups() {
    log "Available MySQL backups in $BACKUP_DIR:"
    echo
    
    if [ ! -d "$BACKUP_DIR" ] || [ -z "$(ls -A "$BACKUP_DIR" 2>/dev/null)" ]; then
        warning "No backups found in $BACKUP_DIR"
        return 0
    fi
    
    echo "Date Created        Size    Filename"
    echo "=================== ======= =========================="
    
    for backup in "$BACKUP_DIR"/*.sql.gz; do
        if [ -f "$backup" ]; then
            local date_created=$(stat -c %y "$backup" | cut -d' ' -f1,2 | cut -d'.' -f1)
            local size=$(ls -lh "$backup" | awk '{print $5}')
            local filename=$(basename "$backup")
            
            printf "%-19s %-7s %s\n" "$date_created" "$size" "$filename"
            
            # Show info if available
            if [ -f "${backup}.info" ]; then
                echo "    MD5: $(grep "MD5:" "${backup}.info" | cut -d' ' -f2)"
            fi
        fi
    done
    echo
    
    # Show total size
    local total_size=$(du -sh "$BACKUP_DIR" 2>/dev/null | cut -f1)
    log "Total backup size: $total_size"
}

# Cleanup old backups
cleanup_backups() {
    local days="${1:-30}"
    log "Cleaning up backups older than $days days..."
    
    if [ ! -d "$BACKUP_DIR" ]; then
        warning "Backup directory not found: $BACKUP_DIR"
        return 0
    fi
    
    # Find and count old backups
    local old_backups=$(find "$BACKUP_DIR" -name "*.sql.gz" -mtime +$days -print)
    local count=$(echo "$old_backups" | grep -c . 2>/dev/null || echo 0)
    
    if [ $count -eq 0 ]; then
        log "No old backups found to clean up"
        return 0
    fi
    
    # Remove old backups and their info files
    find "$BACKUP_DIR" -name "*.sql.gz" -mtime +$days -delete
    find "$BACKUP_DIR" -name "*.info" -mtime +$days -delete
    
    success "Cleaned up $count old backup(s)"
}

# Restore database from backup
restore_backup() {
    local backup_file="$1"
    
    if [ -z "$backup_file" ]; then
        error "Backup file path required"
        echo "Usage: $0 restore <backup_file>"
        return 1
    fi
    
    if [ ! -f "$backup_file" ]; then
        error "Backup file not found: $backup_file"
        return 1
    fi
    
    log "Preparing to restore database from: $backup_file"
    
    # Safety check
    echo
    warning "This will COMPLETELY REPLACE the current database!"
    warning "Make sure to create a backup before proceeding."
    echo
    echo -n "Type 'yes' to confirm restore: "
    read confirmation
    
    if [ "$confirmation" != "yes" ]; then
        log "Restore cancelled by user"
        return 0
    fi
    
    check_container || return 1
    
    log "Starting database restore..."
    
    # Create temporary file for restore
    local temp_file="/tmp/restore_${TIMESTAMP}.sql"
    
    # Decompress if needed
    if [[ "$backup_file" == *.gz ]]; then
        log "Decompressing backup file..."
        gunzip -c "$backup_file" > "$temp_file"
    else
        cp "$backup_file" "$temp_file"
    fi
    
    # Restore database
    if docker exec -i "$CONTAINER_NAME" mysql -u "$DB_USER" -p"$DB_PASS" < "$temp_file"; then
        success "Database restored successfully"
    else
        error "Database restore failed"
        rm -f "$temp_file"
        return 1
    fi
    
    # Cleanup
    rm -f "$temp_file"
    
    success "Restore completed!"
}

# Show container status
show_status() {
    log "MySQL Container Status:"
    echo
    
    if docker ps | grep -q "$CONTAINER_NAME"; then
        docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}" | grep -E "(NAMES|$CONTAINER_NAME)"
        echo
        
        # Show database info
        log "Database Information:"
        docker exec "$CONTAINER_NAME" mysql -u "$DB_USER" -p"$DB_PASS" -e "
            SELECT 'Database Size' as Info, 
                   ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS 'Size (MB)'
            FROM information_schema.tables 
            WHERE table_schema = '$DB_NAME';
            
            SELECT 'Table Count' as Info, COUNT(*) as 'Count'
            FROM information_schema.tables 
            WHERE table_schema = '$DB_NAME';
        " 2>/dev/null || warning "Could not retrieve database information"
    else
        warning "MySQL container '$CONTAINER_NAME' is not running"
        echo
        log "Available containers:"
        docker ps --format "table {{.Names}}\t{{.Status}}"
    fi
}

# Show usage
show_usage() {
    cat << EOF
MySQL Backup Script for Shift Handover Application
==================================================

Usage: $0 [command] [options]

Commands:
  backup [name]     Create a database backup with optional name
  list              List all available backups
  restore <file>    Restore database from backup file
  cleanup [days]    Remove backups older than X days (default: 30)
  test              Test database connection
  status            Show container and database status
  help              Show this help message

Examples:
  $0 backup                              # Create timestamped backup
  $0 backup "before_update"              # Create named backup
  $0 list                                # List all backups
  $0 restore backup_20241026.sql.gz     # Restore from backup
  $0 cleanup 7                          # Remove backups older than 7 days
  $0 test                               # Test database connection
  $0 status                             # Show system status

Configuration:
  Container: $CONTAINER_NAME
  Database:  $DB_NAME
  User:      $DB_USER
  Backup Dir: $BACKUP_DIR
EOF
}

# Main function
case "${1:-help}" in
    backup)
        backup_mysql "$2"
        ;;
    list)
        list_backups
        ;;
    restore)
        restore_backup "$2"
        ;;
    cleanup)
        cleanup_backups "$2"
        ;;
    test)
        test_connection
        ;;
    status)
        show_status
        ;;
    help|--help|-h|"")
        show_usage
        ;;
    *)
        error "Unknown command: $1"
        echo
        show_usage
        exit 1
        ;;
esac